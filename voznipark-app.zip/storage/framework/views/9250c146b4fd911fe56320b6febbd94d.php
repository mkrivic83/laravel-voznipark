<svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <path d="M5.125 0.75L0.875 5L5.125 9.25" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
<?php /**PATH C:\xampp\www\personal\LaravelOOP\voznipark-app\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/chevron-left.blade.php ENDPATH**/ ?>